package com.helis.natttstation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NatTtStationApplicationTests {

    @Test
    void contextLoads() {
    }

}
