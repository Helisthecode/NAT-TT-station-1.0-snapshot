package com.helis.natttstation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NatTtStationApplication {

    public static void main(String[] args) {
        SpringApplication.run(NatTtStationApplication.class, args);
    }

}
