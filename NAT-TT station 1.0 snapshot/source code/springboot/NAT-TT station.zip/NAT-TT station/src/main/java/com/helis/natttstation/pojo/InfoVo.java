package com.helis.natttstation.pojo;

import lombok.Data;

@Data
public class InfoVo {

    private Integer id;
    private String content;
    private String createdTime;
    private Integer isFile;
    private String filename;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getIsFile() {
        return isFile;
    }

    public void setIsFile(Integer isFile) {
        this.isFile = isFile;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }




    @Override
    public String toString() {
        return "InfoVo{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", createdTime='" + createdTime + '\'' +
                ",isFile='"+isFile+
                ",filename='"+filename+
                '}'+"\n";

    }


}
