package com.helis.natttstation.pojo;

import lombok.Data;

@Data
public class Message {
    private Integer id;
    private String content;
    private String createdTime;
    private Integer isFile;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getIsFile() {
        return isFile;
    }

    public void setIsFile(Integer isFile) {
        this.isFile = isFile;
    }

    @Override
    //
    public String toString() {
        return "Message{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", createdTime='" + createdTime + '\'' +
                ",isFile='"+isFile+
                '}';

    }
}
