package com.helis.natttstation.controller;

import com.helis.natttstation.pojo.*;
import com.helis.natttstation.service.ContentService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
//@CrossOrigin(origins = "http://474b7e7e.r2.cpolar.top", allowCredentials = "true")
public class ContentController {
    private static final Logger log= LoggerFactory.getLogger(ContentController.class);//这行代码可以使用@Slf4j注解代替
    @Autowired
    private ContentService contentService;

    //查看message
    //请求方法不影响返回数据的任何安全特性。请求方法（GET/POST）仅决定「前端如何向服务器发送请求参数」，无法干预「服务器如何向前端返回数据」
    @GetMapping("/message")
    public Result getmessage(){
        log.info("查看message");
        List<InfoVo> message = contentService.getInfo();
        return Result.success(message);
    }

    @PostMapping("/sendMess")
    public Result sendMess(@RequestBody Message message){
        log.info("发送message");
        contentService.sendMess(message);
        return Result.success();
    }

    @PostMapping("/fileUpload")
public Result fileUpload(@RequestBody TheFile theFile){

        log.info("文件上传");
        String base64 = theFile.getBase64();
        String filename = theFile.getFilename();
//        System.out.println(">>>>>>>the File:"+theFile);
//        System.out.println(">>>>>>>base64:"+base64);
//        System.out.println(">>>>>>>filename:"+filename);
        contentService.fileUpload(base64,filename);
        return Result.success();

    }

    @GetMapping("/getBase64")
    public Result getBase64(@RequestParam("id") Integer id){
        log.info("获取Base64:", id);
        String base64 = contentService.getBase64(id);
        return Result.success(base64);
    }


}
