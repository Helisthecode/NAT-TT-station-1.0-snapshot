package com.helis.natttstation.pojo;

import lombok.Data;

@Data
public class TheFile {
    private Integer id;
    private Integer messId;
    private String base64;
    private String filename;

    public String getBase64() {
        return base64;
    }

    public void setBase64(String base64) {
        this.base64 = base64;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMessId() {
        return messId;
    }

    public void setMessId(Integer messId) {
        this.messId = messId;
    }

    @Override
    public String toString() {
        return "TheFile{" +
                "id=" + id +
                ", messId=" + messId +
                ", base64='" + base64 + '\'' +
                ", filename='" + filename + '\'' +
                '}';
    }

}
