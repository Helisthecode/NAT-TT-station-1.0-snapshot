package com.helis.natttstation.service.impl;

import com.helis.natttstation.mapper.ContentMapper;
import com.helis.natttstation.pojo.InfoVo;
import com.helis.natttstation.pojo.Message;
import com.helis.natttstation.service.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContentServiceImpl implements ContentService {
    @Autowired
    private ContentMapper contentMapper;

    @Override
    public List<InfoVo> getInfo() {
        return contentMapper.getInfo();
    }

    @Override
    public void sendMess(Message message) {
        contentMapper.insertMess(message);
    }

    @Override
    public void fileUpload(String base64, String filename) {

        //在message表做标记
        contentMapper.insertMessIsFlie();
        //获取message表新id
        Integer messId = contentMapper.getNewId();
        //向文件表插入数据
        contentMapper.insertFile(messId,base64,filename);
    }

    @Override
    public String getBase64(Integer id) {
        return contentMapper.selectBass64(id);
    }


}
