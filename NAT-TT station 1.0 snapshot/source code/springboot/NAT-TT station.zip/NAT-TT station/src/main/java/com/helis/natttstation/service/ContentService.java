package com.helis.natttstation.service;

import com.helis.natttstation.pojo.InfoVo;
import com.helis.natttstation.pojo.Message;
import java.util.List;

public interface ContentService {
    List<InfoVo> getInfo ();

    void sendMess(Message message);

    void fileUpload(String base64,String  filename);


    String getBase64(Integer id);
}
