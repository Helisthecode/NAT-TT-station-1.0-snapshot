package com.helis.natttstation.mapper;


import com.helis.natttstation.pojo.InfoVo;
import com.helis.natttstation.pojo.Message;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ContentMapper {


    @Select("select * from\n" +
            "(select m.id,content,created_time,isFile,filename from thefile f right join message m on f.mess_id = m.id order by m.id desc limit 80)\n" +
            "as info order by id asc ;")
    List<InfoVo> getInfo();

    @Insert("INSERT INTO message(content) values (#{content})")
    void insertMess(Message message);


    @Insert("insert into message(isFile) value (1);")
    void insertMessIsFlie();


    @Select("select id from message order by id desc limit 1;")
    Integer getNewId();

    @Insert("insert into thefile(mess_id,filename,base64) values (#{messId},#{filename},#{base64})")
    void insertFile(Integer messId,String base64, String filename);

    @Select("select base64 from thefile where mess_id=#{id}")
    String selectBass64(Integer id);
}
