<template>
  <div id="container">
    <div id="content">
      <h1 id="head">NAT-TT station 1.0 - SNAPSHOT</h1>
      <span id="subtitle"> welcome</span>
      <el-scrollbar height="540px" width="450px" wrap-style="font-size: 20px;" view-style=""  ref="messageScrollbar">
        <div id="showArea">
          <div id="showAreaContent">
              
            <p v-for="item in messageList" :key="item.id" class="scrollbar-demo-item">
              - {{ item.createdTime }} - <br>
              <!-- 区分文本消息和文件消息 -->
              <template v-if="item.isFile == 0">
                {{ item.content }}
              </template>

              <template v-else-if="item.isFile ==1">
                   <!-- 超过指定宽度自动换行 -->
                    <span style="
                      width: 120px; /* 指定最大宽度 */
                      word-break: break-all; /* 强制换行：支持长单词/无空格字符串换行（核心属性） */
                      white-space: normal; /* 确保文本正常换行，取消单行限制 */
                    ">
                      📎({{ item.filename }})
                    </span>
                  <button 
                    @click="downloadFile(item.filename,item.id)"
                  >
                    download
                  </button>
              </template>
              
            </p>
          </div>
        </div>
      </el-scrollbar>

      <div id="inputArea">
        <div id="inputAreaContent">
          <textarea v-model="content" class="transparent-textarea" placeholder="Please input"></textarea>
          <div class="button-group">
            <el-button type="info" size="small" style="font-size: larger;" round @click="sendClick(),scrollToBottom()" :icon="Promotion" ></el-button>
            <el-button type="info" size="small" circle @click="fileClick">➕</el-button>
            <!-- 原生文件选择框（隐藏，通过按钮点击触发） -->
            <input
              ref="fileInputRef"
              type="file"
              style="display: none;"
              @change="handleFileSelect"
            />
          </div>
          <!-- 顶部按钮 color="(144, 147, 153)"-->
           <el-button style="left: 10%;margin-top: -20%;" @click="scrollToTop()" type="info" :icon="ArrowUpBold" plain></el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { Promotion,ArrowUpBold} from '@element-plus/icons-vue'
const content = ref('') // 绑定输入内容
const fileInputRef = ref(null) // 文件输入框Ref
const messageList = ref([])
import { ElNotification } from 'element-plus'
// 存储图片URL
const imageUrl = ref(null)
const blobUrl = ref(''); // 存储blob格式的URL

onMounted(async() => {
  await getMessage();
  console.log('之后的信息');
  scrollToBottom();
})



// 发送文本消息
const sendClick = () => {
  if (!content.value.trim()) {
    nullError();
    return;
  }

  fetch(`/sendMess`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
      content: content.value,
      type: 'text' // 明确指定消息类型为文本
    })
  })
  .then(res => res.json())
  .then(data => {
    console.log("message：", data);
    if (data) {
      getMessage();

      setTimeout(() => {
        scrollToBottom();
      }, 1000); // 核心：1000ms = 1秒，调整该值可改变延迟时间

      content.value = '';
    }
  })
  .catch(err => {
    console.error(err);
    sendError();
  });
}

// 触发文件选择
const fileClick = () => {
  fileInputRef.value?.click();
}

const thefile=ref(null);
// const base64=ref('');

// 用户文件选择
const handleFileSelect = (event) => {
  const file = event.target.files[0];
  if (!file) return;

  // 检查文件大小（这里限制100MB）
  // const maxSize = 100 * 1024 * 1024; // 10MB
  // if (file.size > maxSize) {
  //   alert('文件大小不能超过100MB');
  //   event.target.value = ''; // 清空选择
  //   return;
  // }

  //file转base64
  const filereader=new FileReader();
  filereader.readAsDataURL(file);
  filereader.onload=async (event)=>{
     const base64=event.target.result;
    console.log(base64);
    uploadFile(base64,file);


  }

  thefile.value=file;
  console.log("thefile:",thefile)
  imageUrl.value=URL.createObjectURL(file);

  event.target.value = ''; // 重置文件选择，允许重复选择同一文件
}

// 上传文件
const uploadFile = async (base64,file) => {
      // 2.  发送给后端
    try {
      const res = await fetch('/fileUpload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ base64: base64, filename: file.name })
      });
      const data = await res.json();
      console.log('上传成功', data);
      getMessage();
      setTimeout(() => {
        scrollToBottom();
      }, 1000); // 核心：1000ms = 1秒，调整该值可改变延迟时间
      uploadedSuccess();
    } catch (err) {
      console.error('上传失败', err);
      uploadedError();
    }
}

// 从后端获取消息列表
const getMessage = async () => {
  try {
    // 去掉 .then，改用 await 接收结果
    const res = await fetch(`/message`);
    const data = await res.json();
    console.log("message：", data.data);
    messageList.value = data.data;
  } catch (err) {
    console.error(err);
  }

};

//当isFile==1,处理文件下载
const downloadFile = async (filename, id) => {
  let base64Str = ''; // 用普通变量存储 base64 字符串，无需 ref

  // 1. 获取 base64 字符串（合并逻辑，保证执行顺序）
  try {
    const res = await fetch(`/getBase64?id=${id}`);
    // 校验接口响应是否成功
    if (!res.ok) {
      throw new Error(`接口请求失败，状态码：${res.status}`);
    }
    const data = await res.json();
    console.log("base64：", data.data);
    base64Str = data.data; // 赋值给普通变量
  } catch (err) {
    console.error("获取 base64 失败：", err);
    return; // 接口失败直接终止函数，不执行后续逻辑
  }

  // 2. base64 转 Blob + 下载
  try {
    // 校验 base64 数据有效性（使用普通变量 base64Str）
    if (!base64Str || !base64Str.includes(',')) {
      console.error('无效的 base64 字符串，缺少前缀分隔符');
      return;
    }

    const arr = base64Str.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
    const bstr = atob(arr[1].replace(/\s/g, ''));
    const len = bstr.length;
    const u8arr = new Uint8Array(len);

    for (let i = 0; i < len; i++) {
      u8arr[i] = bstr.charCodeAt(i);
    }

    const blob = new Blob([u8arr], { type: mime });

    // 移除冗余的 blobUrl 赋值（预留设计，若以后版本 blobUrl 无其他用途，可删除这部分）
    if (blobUrl.value) {
      URL.revokeObjectURL(blobUrl.value);
      blobUrl.value = ''; // 清空无效 URL
    }

    // 直接创建 Blob URL 并下载，无需重复创建
    const a = document.createElement('a');
    const blobUrlTemp = URL.createObjectURL(blob); // 临时 URL，仅用于下载
    a.href = blobUrlTemp;
    a.download = filename; // 必须带文件后缀（如 "test.png"）
    a.click();

    // 立即释放临时 Blob URL，避免内存泄漏
    URL.revokeObjectURL(blobUrlTemp);
    console.log("文件下载触发成功");
  } catch (err) {
    console.error('base64 转 Blob 并下载失败：', err);
  }
};
// 信息提示
const nullError = () => {
  ElNotification({
    title: 'Warning',
    message: 'message cannot be empty!',
    type: 'warning',
    duration: 2000
  })
}

const uploadedSuccess = () => {
  ElNotification({
    title: 'Success',
    message: 'Uploaded successfully!',
    type: 'success',
    duration: 2000
  })
}

const uploadedError = () => {
  ElNotification({
    title: 'Error',
    message: 'Uploaded failed!',
    type: 'error',
    duration: 2000
  })
}
const sendError = () => {
  ElNotification({
    title: 'Error',
    message: 'Send failed!',
    type: 'error',
    duration: 2000
  })
}

// 定义 ref 对应 el-scrollbar
const messageScrollbar = ref(null);
// 滚动到底部的核心方法
const scrollToBottom = () => {
  if (true) {
   const scrollWrapEl = messageScrollbar.value.wrapRef; // 直接获取内部滚动容器 ref
    if (scrollWrapEl) {
      // 明确设置滚动目标为 滚动内容总高度 - 容器可视高度（即最底部）
      const bottomTop = scrollWrapEl.scrollHeight - scrollWrapEl.clientHeight;
      messageScrollbar.value.scrollTo({
        top: bottomTop, // 明确底部位置，避免 Infinity 导致的方向异常
        behavior: 'smooth' // 
      });
    }
  }
};
// 滚动到顶部的核心方法
const scrollToTop = () => {
  if (messageScrollbar.value) {
    // el-scrollbar 内置 scrollTo 方法，滚动到底部（y 轴最大值）
    messageScrollbar.value.scrollTo({
      top: 0, 
      behavior: 'smooth' // 可选：平滑滚动，移除则立即滚动
    });
  }
};
</script>

<style scoped>
   /* 导入字体 */
  @font-face{
      font-family: FR;
      src: url('../fonts/FREESCPT.TTF');/*'Freestyle Script'*/
  }
  @font-face{
     font-family: AG;
      src: url('../fonts/AGENCYR.TTF');/*'Agency FB'*/
  }
#container {
  width: 450px;
  height: 650px;
  background-color: rgb(44, 46, 46);
  left: 50%;
  border: 2px solid rgb(134, 128, 128);
  border-radius: 10%;
  position: relative; /*确保内部绝对定位元素正常工作 */
}
#content {
  
  width: 100%;
  position: absolute;
  left: 0%;
}
.scrollbar-demo-item {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 50px;
  margin: 10px;
  text-align: center; 
  border-radius: 4px;
  background: rgb(68, 67, 67);
  color: rgb(172, 171, 171);
  white-space: normal;
  overflow-wrap: break-word;
  word-wrap: break-word;
  word-break: break-all;
  padding: 0 10px; /* 增加内边距，避免文字贴边 */
}
#head {
  margin-left: 12%;
  display: inline-block;
    /* 优先使用微软雅黑，没有则用Arial，最后用系统默认无衬线字体 */
  font-family: 'AG', 'Microsoft YaHei', sans-serif;
  text-align: center;
  color: rgb(224, 218, 218); /* 标题颜色 */
}
#subtitle{
  font-size: 25px;
  font-family: 'FR','Microsoft YaHei',sans-serif;
}
#inputArea {
  border-top: 1.5px solid rgb(134, 128, 128);
  padding-bottom: 10px; /* 增加底部 padding */
}
#inputAreaContent {
  margin-left: 5%;
  top: 5%;
  left: 5%;
  display: flex;
  position: relative;
  align-items: flex-start;
  gap: 10px;
}
.transparent-textarea {
  margin-top: 3px;
  background: transparent;
  border: 1px solid rgb(134, 128, 128);
  border-radius: 4px; /* 稍微增大圆角 */
  width: 340px; 
  min-height: 47px;
  resize: none;
  scrollbar-width: none;
  -ms-overflow-style: none;
  color: rgb(224, 218, 218);
  font-size: large;
  padding: 5px; /* 增加内边距，提升输入体验 */
}
/* 隐藏textarea滚动条 */
.transparent-textarea::-webkit-scrollbar {
  display: none;
}
.button-group {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-top: 3px;
  width: 50px;
}

</style>