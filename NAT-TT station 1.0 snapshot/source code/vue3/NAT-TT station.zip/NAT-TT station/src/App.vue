<script setup>
  import mainpage from './views/mainpage.vue'
</script>

<template>
  <mainpage />

  
</template>

<style scoped>


</style>
